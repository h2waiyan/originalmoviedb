import { Component } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Subscription } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  constructor(private apiService: ApiService) { }

  movieSub: Subscription = new Subscription();

  popularMovieList = []

  getPopularMovie() {
    var result = this.apiService.getMovies('popular');
    this.movieSub = result.subscribe({
      next: (response: any) => {
        this.popularMovieList = response['results']
      },
      error: (err: HttpErrorResponse) => {
        console.log(err);
      }
    })
  }

  getNowPlayingMovie() {
    this.apiService.getMovies('now_playing');
  }

  getTopRatedMovie() {
    this.apiService.getMovies('top_rated');
  }

  getUpcomingMovie() {
    this.apiService.getMovies('upcoming');
  }
}
